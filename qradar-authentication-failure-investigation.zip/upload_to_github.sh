
git init
git add .
git commit -m "Initial QRadar SIEM project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/qradar-authentication-failure-investigation.git
git push -u origin main
