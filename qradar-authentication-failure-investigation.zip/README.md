
# qradar-authentication-failure-investigation

This project demonstrates:
- Log parsing
- Failed login detection
- Brute force attack detection
- QRadar correlation rule examples
- Incident analysis documentation

## Features
- Detects multiple failed login attempts
- Generates alerts for suspicious activity
- Example QRadar rule configuration
- Root Cause Analysis report

## Run the Project

Install dependencies:
```bash
pip install -r requirements.txt
```

Run parser:
```bash
python parse_logs.py
```

## GitHub Upload

Initialize Git:
```bash
git init
git add .
git commit -m "Initial commit"
```

Create GitHub repo and push:
```bash
git remote add origin https://github.com/YOUR_USERNAME/qradar-project.git
git branch -M main
git push -u origin main
```
