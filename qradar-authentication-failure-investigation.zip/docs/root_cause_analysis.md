
# Root Cause Analysis

## Incident
Multiple failed login attempts were detected from a single IP address.

## Findings
- Source IP repeatedly attempted authentication.
- Threshold exceeded 5 failed logins.
- Potential brute-force attack identified.

## Recommendation
- Block malicious IP.
- Enable MFA.
- Monitor authentication logs continuously.
