
import re
from collections import defaultdict

LOG_FILE = "logs/sample_logs.txt"

failed_attempts = defaultdict(int)

def parse_logs():
    try:
        with open(LOG_FILE, "r") as file:
            logs = file.readlines()

        for line in logs:
            if "FAILED LOGIN" in line:
                match = re.search(r'IP=(\d+\.\d+\.\d+\.\d+)', line)

                if match:
                    ip = match.group(1)
                    failed_attempts[ip] += 1

        print("\n=== Failed Login Summary ===")
        for ip, count in failed_attempts.items():
            print(f"{ip} -> {count} failed attempts")

            if count >= 5:
                print(f"[ALERT] Possible brute-force attack detected from {ip}")

    except FileNotFoundError:
        print("Log file not found.")

if __name__ == "__main__":
    parse_logs()
